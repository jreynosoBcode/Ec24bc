// Initialize app
var myApp = new Framework7();


// If we need to use custom DOM library, let's save it to $$ variable:
var $$ = Dom7;
var mainView = myApp.addView('.view-main', {
  dynamicNavbar: true
});
// Add view
/*var mainView = myApp.addView('.view-main', {
    // Because we want to use dynamic navbar, we need to enable it for this view:
    dynamicNavbar: true
});¨*/

// Handle Cordova Device Ready Event
$$(document).on('deviceready', function() {
    console.log("Device is ready!");
});


// Now we need to run the code that will be executed only for About page.

// Option 1. Using page callback for page (for "about" page in this case) (recommended way):
myApp.onPageInit('about', function (page) {
    // Do something here for "about" page

})

// Option 2. Using one 'pageInit' event handler for all pages:
$$(document).on('pageInit', function (e) {
    // Get page data from event data
    var page = e.detail.page;

    if (page.name === 'about') {
        // Following code will be executed for page with data-page attribute equal to "about"
        myApp.alert('Here comes About page');
    }
})

// Option 2. Using live 'pageInit' event handlers for each page
$$(document).on('pageInit', '.page[data-page="about"]', function (e) {
    // Following code will be executed for page with data-page attribute equal to "about"
    myApp.alert('Here comes About page');
})


function buscarTaxi(){
    // Initialize View          
    alert("entra");
    var mainView = myApp.addView('#contenido_pagina');
    // Load page from about.html file to main View:
    mainView.router.loadPage('buscarTaxi.html');
}

/*
var btnNotificacion = document.getElementById("buttonN"),  
    btnPermiso = document.getElementById("buttonP")
    titulo = "Fili Santillán",
    opciones = {
        icon: "logo.png",
        body: "Notificación de prueba"
    };

function permiso() {  
        Notification.requestPermission();
};

function mostrarNotificacion() {  
    if(Notification) {
        if (Notification.permission == "granted") {
            var n = new Notification(titulo, opciones);
        }

        else if(Notification.permission == "default") {
            alert("Primero da los permisos de notificación");
        }

        else {
            alert("Bloqueaste los permisos de notificación");
        }
    }
};

btnPermiso.addEventListener("click", permiso);  
btnNotificacion.addEventListener("click", mostrarNotificacion);  

*/
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
var gmail;
function login(){
    window.location="inicio.html";
}
function closeSession(){
    window.localStorage.removeItem("loggedIn");
    window.localStorage.removeItem("username");
    window.location.replace("index.html");
}
function autorizado(){
    if(window.localStorage.getItem("loggedIn") == 1) {
    // Logged In
    // Redirect to first page after logged in.
    }
    else
    {
        window.location.replace("index.html");
    }
}

function perfil() {
    $("contenido_pagina").each(function()
    {
        var
        target = $(this),
        request = new XMLHttpRequest();
         
        request.open('GET', target.attr("data-url"), true);
     
        request.onreadystatechange = function()
        {
            if(request.readyState === 4)
            {
                if(request.status === 200 || request.status === 0)
                {
                    target.html(request.responseText);
                                         
                 //   console.log('File "' + target.attr("data-url") + '" loaded to #' + target.attr("id") + ' tab!');
                }
            }
        }
         
        request.send();
    });
}
